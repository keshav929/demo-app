import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiLayerService {

  constructor() { }

  getData(param)
  {
    return JSON.parse(localStorage.getItem(param));
  }

  postData(param,data,dataType)
  {
    if(dataType=="list")
    {
      let oldData = this.getData(param);
      oldData = oldData==null?[]:oldData;
      oldData.push(data);
      localStorage.setItem(param,JSON.stringify(oldData));
    }
    else
    {
      localStorage.setItem(param,data);
    }

  }

}
