import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProjectsComponent } from './components/projects/projects.component';
import { FullLayoutComponent } from './components/full-layout/full-layout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { RightViewComponent } from './components/right-view/right-view.component';
import { TimeTrackerComponent } from './components/time-tracker/time-tracker.component';
import { ApiLayerService } from './Services/api-layer.service';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ProjectsComponent,
    FullLayoutComponent,
    SidebarComponent,
    RightViewComponent,
    TimeTrackerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [ApiLayerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
