import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-view',
  templateUrl: './right-view.component.html',
  styleUrls: ['./right-view.component.css']
})
export class RightViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
