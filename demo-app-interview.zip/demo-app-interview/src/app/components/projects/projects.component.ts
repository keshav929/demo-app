import { Component, OnInit } from '@angular/core';
import { ApiLayerService } from "../../../app/Services/api-layer.service";
@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {
projectName:string="";

  constructor(private localStorageService:ApiLayerService) { }

  ngOnInit(): void {
  }

  createProject()
  {
    let data={projectName:document.getElementById('project_name').value};
    debugger;
    this.localStorageService.postData("projectsList",data,"list");
  }
  closePop()
  {
    document.body.classList.remove('show');
  }
  showPop()
  {
    document.body.classList.add('show');
  }
}
