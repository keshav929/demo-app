import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '../app/components/dashboard/dashboard.component';
import { ProjectsComponent } from '../app/components/projects/projects.component';
import { TimeTrackerComponent } from '../app/components/time-tracker/time-tracker.component';
const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent},
  { path: 'projects', component: ProjectsComponent},
  { path: 'time-tracker', component: TimeTrackerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
